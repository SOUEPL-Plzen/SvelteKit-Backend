import { db } from '$lib/db';
import { user } from '$lib/db/schema';

export async function load() {
	const users = await db.select().from(user);
	return { users };
}
