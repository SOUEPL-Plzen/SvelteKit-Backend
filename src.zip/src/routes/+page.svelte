<script>
	let age = $state('');
	let selectedUserId = $state('');
	const selectedUser = $state(null);
	let users = $state([]);

	// Načteme uživatele při načtení stránky
	async function loadUsers() {
		const response = await fetch('/api/get-users');
		users.set(await response.json());
	}

	// Přidání nového uživatele přes API
	async function addUser() {
		const formData = new FormData();
		formData.append('age', age);

		await fetch('/api/add-user', {
			method: 'POST',
			body: formData
		});

		// Aktualizujeme seznam uživatelů
		await loadUsers();
	}

	// Získání uživatele podle ID přes API
	async function getUserById() {
		const response = await fetch(`/api/get-user-by-id?id=${selectedUserId}`);
		const result = await response.json();
		selectedUser.set(result.selectedUser);
	}

	// Načteme uživatele při prvním renderu
	$effect(() => {
		loadUsers();
	});
</script>

<h1>Správa uživatelů</h1>

<!-- Formulář pro přidání uživatele -->
<div>
	<input type="number" placeholder="Věk" bind:value={age} />
	<button onclick={addUser}>Přidat uživatele</button>
</div>

<!-- Výpis všech uživatelů -->
<h2>Seznam uživatelů</h2>
<ul>
	{#each users as user}
		<li>ID: {user.id}, Věk: {user.age}</li>
	{/each}
</ul>

<!-- Input pro výběr uživatele podle ID -->
<div>
	<select bind:value={selectedUserId}>
		<option value="" disabled>Vyber ID uživatele</option>
		{#each users as user}
			<option value={user.id}>{user.id}</option>
		{/each}
	</select>
	<button onclick={getUserById}>Zobrazit uživatele</button>
</div>

<!-- Zobrazení vybraného uživatele -->
{#if selectedUser}
	<h2>Detail uživatele</h2>
	<p>ID: {$selectedUser.id}</p>
	<p>Věk: {$selectedUser.age}</p>
{/if}
