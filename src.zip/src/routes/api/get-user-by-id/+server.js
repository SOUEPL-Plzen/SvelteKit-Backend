import { db } from '$lib/db';
import { user } from '$lib/db/schema';

export async function GET({ url }) {
	const id = parseInt(url.searchParams.get('id'));

	if (isNaN(id)) {
		return new Response(JSON.stringify({ error: 'Neplatné ID' }), { status: 400 });
	}

	const selectedUser = await db.select().from(user).where(user.id.eq(id)).get();
	return new Response(JSON.stringify({ selectedUser }), { status: 200 });
}
