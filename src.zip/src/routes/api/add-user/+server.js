import { db } from '$lib/db';
import { user } from '$lib/db/schema';

export async function POST({ request }) {
	const formData = await request.formData();
	const age = parseInt(formData.get('age'));

	if (isNaN(age)) {
		return new Response(JSON.stringify({ error: 'Neplatný věk' }), { status: 400 });
	}

	await db.insert(user).values({ age });
	return new Response(JSON.stringify({ message: 'Uživatel přidán' }), { status: 200 });
}
